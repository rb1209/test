import json
import boto3

def lambda_handler(event, context):
    # TODO implement
    s3 = boto3.client('s3')
    data = s3.get_object(Bucket='my-data-source-bucket', Key='data.txt')
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
