import os
import html2text

def extract(dir_path):
    files = os.listdir(dir_path)
    h = html2text.HTML2Text()
    h.ignore_links = True
    html_string = ""
    for file in files:
        with open(dir_path+file, encoding="utf-8") as html:
            #f.write(h.handle(dir_path+file))
            try: 
                html_string+=html.read()
            except:
                continue

    with open('../temp/data.txt',"w",encoding="utf-8") as f:
        f.write(h.handle(html_string))
            
extract("../data/")