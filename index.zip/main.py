# installs from https://gpt-index.readthedocs.io/en/latest/getting_started/installation.html
# code based on https://gpt-index.readthedocs.io/en/latest/getting_started/starter_example.html
import os
import openai

os.environ["OPENAI_API_KEY"]="sk-e2ejp9oIwRHtXs2p0gPN3BlbkFJtQBHTGMikCs4WyHGYVhy"
openai.api_key = "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"
from llama_index import SimpleDirectoryReader,query_engine,TreeIndex

documents = SimpleDirectoryReader("temp").load_data()
new_index = TreeIndex.from_documents(documents)


query_engine = new_index.as_query_engine()
response = query_engine.query("What did the author do growing up?")
print(response)

# # rebuild storage context
# storage_context = StorageContext.from_defaults(persist_dir="<persist_dir>")

# # load index
# #index = load_index_from_storage(storage_context)
